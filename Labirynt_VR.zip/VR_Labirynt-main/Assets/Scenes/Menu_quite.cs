using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Menu_quite : MonoBehaviour
{
    public void ExitGame()
    {
        Application.Quit();
    }
}
