using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class XR_FakeTeleport : MonoBehaviour
{
    public Transform destination; // Punkt docelowy teleportacji
    public GameObject gracz;      // Obiekt "Gracz" (ca�y XR Rig)
    public AudioClip teleportSound; // D�wi�k teleportacji

    private AudioSource audioSource;

    void Start()
    {
        // Dodajemy komponent AudioSource do obiektu z tym skryptem
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = teleportSound;
        audioSource.playOnAwake = false; // Nie odtwarzaj d�wi�ku przy starcie
    }

    void OnTriggerEnter(Collider other)
    {
        // Sprawdzamy, czy obiekt koliduj�cy to nasz XR Rig
        if (other.gameObject.CompareTag("Player"))
        {
            // Odtwarzamy d�wi�k teleportacji
            audioSource.Play();

            // Wy��czamy kontroler ruchu, aby unikn�� problem�w
            var moveProvider = gracz.GetComponent<UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider>();
            if (moveProvider != null)
            {
                moveProvider.enabled = false;
            }

            // Przenosimy gracza na punkt docelowy
            gracz.transform.position = destination.position;

            // W��czamy kontroler ruchu ponownie
            if (moveProvider != null)
            {
                moveProvider.enabled = true;
            }
        }
    }
}
