![image](https://github.com/user-attachments/assets/d1eab171-1981-453e-af58-ad62fa648dfb)

![image](https://github.com/user-attachments/assets/932abf62-1a51-4591-9d76-7ab7a96cb146)

![image](https://github.com/user-attachments/assets/f0ebad03-f7f6-48f6-b630-7c57b1ae514a)

![image](https://github.com/user-attachments/assets/7fd93feb-7469-43bb-ab0e-bd8c579c7e49)
